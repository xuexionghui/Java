```
[htps]+://([a-zA-Z0-9\.:-]+)/

\.clientSecret\("(.*)"\)

\.clientId\("(.*)"\)

\.alipayPublicKey\("(.*)"\)
```